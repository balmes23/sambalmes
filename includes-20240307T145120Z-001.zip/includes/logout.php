<?php
include_once('server.php');
session_destroy();
unset($_SESSION['username']);
unset($_SESSION['name']);

session_start();
$_SESSION['message'] = "Logged out";
$_SESSION['success'] = 'danger';

header('location: ../login.php');
