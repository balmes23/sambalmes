<?php

$database = 'balmesfolio';
$username = 'root';
$host = 'localhost';
$password = '';

$db = new mysqli($host, $username, $password, $database);

if (!isset($_SESSION)) {
  session_start(); //initialize $_SESSION
}
