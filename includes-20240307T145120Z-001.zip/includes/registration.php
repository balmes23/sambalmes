<?php

include_once('server.php');

$asLname = $db->real_escape_string($_POST['asLname']);
$asFname = $db->real_escape_string($_POST['asFname']);
$asEmail = $db->real_escape_string($_POST['asEmail']);
$asContactNo = $db->real_escape_string($_POST['asContactNo']);
$country = $db->real_escape_string($_POST['country']);
$province = $db->real_escape_string($_POST['province']);
$city = $db->real_escape_string($_POST['city']);
$brgy = $db->real_escape_string($_POST['brgy']);
$lot = $db->real_escape_string($_POST['lot']);
$street = $db->real_escape_string($_POST['street']);
$asPass = md5($db->real_escape_string($_POST['asPass']));
$asPassConfirm = md5($db->real_escape_string($_POST['asPassConfirm']));
$subdivision = $db->real_escape_string($_POST['subdivision']);

if ($asPassConfirm == $asPass) {
  $query = "INSERT INTO account (first, last, num, email, country, province, city, brgy, block, street, subdivision, pass) VALUES ('$asFname', '$asLname', '$asContactNo', '$asEmail', '$country', '$province', '$city', '$brgy', '$lot', '$street', '$subdivision', '$asPass')";
  if ($db->query($query)) {
    $_SESSION['errors'] = 'Sign up successful!';
    $_SESSION['alerttype'] = 'success';
    header("Location: ../login.php");
  } else {
    $_SESSION['errors'] = 'Sign up failed!';
    $_SESSION['alerttype'] = 'danger';
    header("Location: ../register.php");
  }
} else {
  $_SESSION['errors'] = 'Password do not match!';
  $_SESSION['alerttype'] = 'danger';
  header("Location: ../register.php");
}
$db->close();
