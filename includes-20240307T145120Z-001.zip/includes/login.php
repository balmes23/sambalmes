<?php

include_once('server.php');

$email = $db->real_escape_string($_POST['email']);
$password = md5($db->real_escape_string($_POST['password']));

$query = "SELECT * FROM account WHERE email = '$email' AND pass = '$password'";

$result = $db->query($query);

if ($result->num_rows) {
  while ($row = $result->fetch_assoc()) {
    $_SESSION['username'] = $row['email'];
    $_SESSION['first'] = $row['first'];
    $_SESSION['last'] = $row['last'];
  }

  header('location: ../index.php');
} else {
  $_SESSION['errors'] = 'Incorrect email or password';
  $_SESSION['alerttype'] = 'danger';
  header('Location: ../login.php');
}


$db->close();
